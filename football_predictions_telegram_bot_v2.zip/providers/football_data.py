import os
import time
import httpx
from datetime import date, datetime
from models import Fixture, TeamForm

class FootballDataProvider:
    BASE = "https://api.football-data.org/v4"

    def __init__(self):
        self.token = os.getenv("FOOTBALL_DATA_API_TOKEN", "")
        self.competitions = [x.strip().upper() for x in os.getenv(
            "COMPETITIONS", "PL,PD,BL1,SA,FL1,DED,PPL"
        ).split(",") if x.strip()]
        self.cache_seconds = int(os.getenv("CACHE_SECONDS", "120"))
        self.cache = {}
        if not self.token:
            raise RuntimeError("FOOTBALL_DATA_API_TOKEN is missing")

    async def _get(self, path, params=None):
        key=(path, tuple(sorted((params or {}).items())))
        now=time.time()
        cached=self.cache.get(key)
        if cached and now-cached[0] < self.cache_seconds:
            return cached[1]
        async with httpx.AsyncClient(timeout=25) as client:
            r=await client.get(
                self.BASE+path,
                headers={"X-Auth-Token": self.token},
                params=params or {}
            )
            r.raise_for_status()
            data=r.json()
        self.cache[key]=(now,data)
        return data

    async def fixtures_on_date(self, day: date):
        out=[]
        for code in self.competitions:
            data=await self._get(
                f"/competitions/{code}/matches",
                {"dateFrom":day.isoformat(),"dateTo":day.isoformat()}
            )
            for m in data.get("matches",[]):
                dt=datetime.fromisoformat(m["utcDate"].replace("Z","+00:00"))
                if dt.date()!=day:
                    continue
                odds=m.get("odds") or {}
                out.append(Fixture(
                    fixture_id=m["id"],
                    competition=m["competition"]["name"],
                    competition_code=code,
                    home_id=m["homeTeam"]["id"],
                    home_name=m["homeTeam"]["name"],
                    away_id=m["awayTeam"]["id"],
                    away_name=m["awayTeam"]["name"],
                    utc_date=dt,
                    status=m.get("status","UNKNOWN"),
                    odds_home=odds.get("homeWin"),
                    odds_draw=odds.get("draw"),
                    odds_away=odds.get("awayWin"),
                ))
        return list({x.fixture_id:x for x in out}.values())

    async def recent_matches(self, team_id:int, limit:int=10):
        data=await self._get(
            f"/teams/{team_id}/matches",
            {"status":"FINISHED","limit":limit}
        )
        return data.get("matches",[])

    @staticmethod
    def _result_for_team(m, team_id):
        score=m.get("score",{}).get("fullTime",{})
        h=score.get("home")
        a=score.get("away")
        if h is None or a is None:
            return None
        home_id=m.get("homeTeam",{}).get("id")
        away_id=m.get("awayTeam",{}).get("id")
        if team_id==home_id:
            gf,ga=h,a
        elif team_id==away_id:
            gf,ga=a,h
        else:
            return None
        pts=3 if gf>ga else 1 if gf==ga else 0
        return gf,ga,pts,home_id==team_id

    async def team_form(self, team_id:int, limit:int=10):
        matches=await self.recent_matches(team_id,limit)
        rows=[]
        for m in matches:
            r=self._result_for_team(m,team_id)
            if r: rows.append(r)
        if not rows:
            return None
        n=len(rows)
        gf=sum(r[0] for r in rows)/n
        ga=sum(r[1] for r in rows)/n
        pr=sum(r[2] for r in rows)/(3*n)
        home=[r for r in rows if r[3]]
        away=[r for r in rows if not r[3]]
        cs=sum(1 for r in rows if r[1]==0)/n
        fts=sum(1 for r in rows if r[0]==0)/n
        return TeamForm(
            team_id=team_id,
            name=str(team_id),
            matches=n,
            points_rate=pr,
            goals_for_rate=gf,
            goals_against_rate=ga,
            home_points_rate=(sum(r[2] for r in home)/(3*len(home)) if home else None),
            away_points_rate=(sum(r[2] for r in away)/(3*len(away)) if away else None),
            clean_sheet_rate=cs,
            failed_to_score_rate=fts
        )

    async def search_fixture(self, home:str, away:str, day:date):
        hs=home.lower().strip()
        aw=away.lower().strip()
        for f in await self.fixtures_on_date(day):
            if hs in f.home_name.lower() and aw in f.away_name.lower():
                return f
        return None
