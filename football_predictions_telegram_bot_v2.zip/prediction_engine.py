import math, os
from models import Fixture, Prediction

def clamp(x,a,b): return max(a,min(b,x))

def implied(odds):
    return 1/odds if odds and odds>1 else None

def poisson(k,l):
    return math.exp(-l)*(l**k)/math.factorial(k)

def distribution(hx,ax,max_goals=7):
    d={}
    total=0
    for h in range(max_goals+1):
        for a in range(max_goals+1):
            p=poisson(h,hx)*poisson(a,ax)
            d[(h,a)]=p
            total+=p
    return {k:v/total for k,v in d.items()}

def probs(hx,ax):
    d=distribution(hx,ax)
    def s(fn): return sum(p for (h,a),p in d.items() if fn(h,a))
    return {
        "Home Win":s(lambda h,a:h>a),
        "Draw":s(lambda h,a:h==a),
        "Away Win":s(lambda h,a:h<a),
        "Home or Draw":s(lambda h,a:h>=a),
        "Away or Draw":s(lambda h,a:h<=a),
        "Home or Away":s(lambda h,a:h!=a),
        "Over 0.5 Goals":s(lambda h,a:h+a>=1),
        "Over 1.5 Goals":s(lambda h,a:h+a>=2),
        "Over 2.5 Goals":s(lambda h,a:h+a>=3),
        "Under 2.5 Goals":s(lambda h,a:h+a<=2),
        "Under 3.5 Goals":s(lambda h,a:h+a<=3),
        "BTTS — Yes":s(lambda h,a:h>=1 and a>=1),
        "BTTS — No":s(lambda h,a:h==0 or a==0),
    }

class PredictionEngine:
    def __init__(self,provider):
        self.provider=provider
        self.min_conf=float(os.getenv("MIN_CONFIDENCE","75"))
        self.low=float(os.getenv("LOW_RISK_MIN_CONFIDENCE","82"))
        self.recent=int(os.getenv("RECENT_MATCHES","10"))

    async def analyze(self,f:Fixture):
        hf=await self.provider.team_form(f.home_id,self.recent)
        af=await self.provider.team_form(f.away_id,self.recent)

        if not hf or not af:
            return self.avoid(f,50,"Insufficient verified recent-match data.")

        # Baseline expected goals. This is deliberately conservative:
        # scoring form is blended with the opponent's conceding rate.
        home_attack=hf.goals_for_rate
        away_attack=af.goals_for_rate
        home_def=hf.goals_against_rate
        away_def=af.goals_against_rate

        hx=0.58*home_attack + 0.42*away_def + 0.18
        ax=0.58*away_attack + 0.42*home_def

        # Recent points rate gives a bounded strength adjustment.
        hx*=clamp(0.90 + 0.20*(hf.points_rate-af.points_rate),0.84,1.08)
        ax*=clamp(0.92 + 0.16*(af.points_rate-hf.points_rate),0.84,1.06)
        hx=clamp(hx,0.20,3.50)
        ax=clamp(ax,0.15,3.20)

        p=probs(hx,ax)

        # Conservative market preference.
        candidates=[
            ("Home or Draw",p["Home or Draw"]),
            ("Away or Draw",p["Away or Draw"]),
            ("Over 1.5 Goals",p["Over 1.5 Goals"]),
            ("Under 3.5 Goals",p["Under 3.5 Goals"]),
            ("Home Win",p["Home Win"]),
            ("Away Win",p["Away Win"]),
            ("BTTS — No",p["BTTS — No"]),
            ("BTTS — Yes",p["BTTS — Yes"]),
        ]
        pick,prob=max(candidates,key=lambda x:x[1])

        data_quality=0.78
        if hf.matches>=8 and af.matches>=8: data_quality+=0.07
        if f.odds_home and f.odds_draw and f.odds_away: data_quality+=0.05
        data_quality=clamp(data_quality,0.55,0.95)

        confidence=prob*100
        # Confidence is probability adjusted for data quality.
        confidence=50+(confidence-50)*data_quality
        confidence=clamp(confidence,50,94.5)

        if confidence<self.min_conf:
            return self.avoid(f,confidence,"No available market reached the configured safety threshold.")

        risk="🟢 Low" if confidence>=self.low else "🟡 Moderate"

        # Odds: remove overround and report edge only if odds exist.
        ip=None; edge=None
        odds={"Home Win":f.odds_home,"Draw":f.odds_draw,"Away Win":f.odds_away}
        raw=[implied(f.odds_home),implied(f.odds_draw),implied(f.odds_away)]
        if all(x is not None for x in raw):
            total=sum(raw)
            normalized={k:(v/total) for k,v in zip(["Home Win","Draw","Away Win"],raw)}
            if pick in normalized:
                ip=normalized[pick]
                edge=prob-ip

        d=distribution(hx,ax)
        (sh,sa),_=max(d.items(),key=lambda x:x[1])

        reasons=[
            f"Recent scoring/conceding rates imply approximately {hx:.2f} home and {ax:.2f} away expected goals.",
            f"Recent points-rate comparison: {hf.points_rate:.0%} home team, {af.points_rate:.0%} away team.",
            "The primary market was selected from conservative alternatives before considering higher-risk outcomes."
        ]
        if edge is not None:
            reasons.append(f"Normalized 1X2 market comparison gives an estimated model edge of {edge*100:+.1f} percentage points.")
            reasons=reasons[:3]

        return Prediction(
            fixture=f,pick=pick,confidence=round(confidence,1),risk=risk,
            correct_score=f"{sh}–{sa}",reasons=reasons,
            estimated_probability=prob,data_quality=data_quality,
            implied_probability=ip,value_edge=edge
        )

    def avoid(self,f,c,reason):
        return Prediction(
            fixture=f,pick="AVOID",confidence=round(c,1),
            risk="🔴 High",correct_score="—",reasons=[reason],
            estimated_probability=0,data_quality=0,avoided=True,
            avoid_reason=reason
        )

    async def analyze_many(self,fixtures,max_picks):
        results=[]
        for f in fixtures:
            try:
                p=await self.analyze(f)
                if not p.avoided:
                    results.append(p)
            except Exception:
                continue
        results.sort(key=lambda x:x.confidence,reverse=True)
        return results[:max_picks]
