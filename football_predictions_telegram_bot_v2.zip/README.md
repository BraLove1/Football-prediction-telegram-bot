# Professional Football Predictions Telegram Bot — V2

This version implements a more serious safety-first prediction pipeline.

## Core pipeline

1. Parse the exact requested date.
2. Retrieve fixtures for that date.
3. Re-check the fixture's calendar date.
4. Exclude cancelled/postponed fixtures.
5. Pull recent completed matches for both teams.
6. Calculate recent points, scoring and conceding rates.
7. Estimate expected goals with home advantage and form adjustments.
8. Generate a Poisson scoreline distribution.
9. Calculate probabilities for conservative markets.
10. Compare market odds when supplied.
11. Apply data-quality penalties.
12. Reject selections below the safety threshold.
13. Return one market per match.
14. Produce a final exact-date safety summary.

## Telegram commands

/predict YYYY-MM-DD [max]
/today
/tomorrow
/analyze HOME vs AWAY
/help

Examples:

/predict 2026-10-05 12
/predict 2026-10-05 5

## Data-source reality

The included adapter uses football-data.org v4. Its API exposes competition matches, standings and team-match history. Coverage and data fields depend on your plan. The bot therefore does NOT invent xG, injuries, suspensions, lineups or odds when the provider does not supply them.

For richer production data, implement another adapter under `providers/` and keep the engine unchanged.

## Install

Python 3.10+:

```bash
python -m venv .venv
source .venv/bin/activate       # Linux/macOS
# .venv\Scripts\activate       # Windows

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and set the two tokens.

Run:

```bash
python bot.py
```

## Create Telegram bot

Use Telegram's official @BotFather to create the bot and copy the bot token into `.env`.

## Football API

Create a football-data.org account and place the API token in `.env`.

The provider's current documentation describes `/v4/competitions/{id}/matches` with date filters, `/v4/teams/{id}/matches` for team history, and standings endpoints. Coverage and plans are documented on their site.

## Production recommendations

For a production-grade model, add:

- an xG-capable data source
- verified injury/suspension feed
- expected/confirmed lineup feed
- broader league coverage
- bookmaker odds API
- odds movement snapshots
- historical database
- backtesting
- probability calibration
- automated CLV/result tracking

Those should be added as actual data integrations, not simulated fields.

## Disclaimer

The bot produces probabilistic analysis. It cannot guarantee a football result or a winning bet.
