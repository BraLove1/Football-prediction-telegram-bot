from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class Fixture:
    fixture_id: int
    competition: str
    competition_code: str
    home_id: int
    home_name: str
    away_id: int
    away_name: str
    utc_date: datetime
    status: str
    odds_home: Optional[float] = None
    odds_draw: Optional[float] = None
    odds_away: Optional[float] = None

@dataclass
class TeamForm:
    team_id: int
    name: str
    matches: int
    points_rate: float
    goals_for_rate: float
    goals_against_rate: float
    home_points_rate: Optional[float] = None
    away_points_rate: Optional[float] = None
    clean_sheet_rate: Optional[float] = None
    failed_to_score_rate: Optional[float] = None

@dataclass
class Prediction:
    fixture: Fixture
    pick: str
    confidence: float
    risk: str
    correct_score: str
    reasons: list[str]
    estimated_probability: float
    data_quality: float
    avoided: bool = False
    avoid_reason: Optional[str] = None
    implied_probability: Optional[float] = None
    value_edge: Optional[float] = None
