from datetime import timezone

def esc(s):
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

def prediction_block(p):
    f=p.fixture
    rs="\n".join("• "+esc(x) for x in p.reasons)
    return (
        f"<b>Match:</b> {esc(f.home_name)} vs {esc(f.away_name)}\n"
        f"<b>Competition:</b> {esc(f.competition)}\n"
        f"<b>Date:</b> {f.utc_date.astimezone(timezone.utc).strftime('%Y-%m-%d')}\n"
        f"<b>Pick:</b> {esc(p.pick)}\n"
        f"<b>Confidence:</b> {p.confidence:.1f}%\n"
        f"<b>Risk:</b> {p.risk}\n"
        f"<b>Correct Score:</b> {esc(p.correct_score)}\n\n"
        f"<b>Reasoning:</b>\n{rs}"
    )

def report(preds,day,maxn,total):
    out=[
        "⚽ <b>PROFESSIONAL FOOTBALL PREDICTIONS</b>",
        f"📅 <b>Analysis date:</b> {day.isoformat()}",
        "🛡️ <b>Safety-first mode:</b> ON",
        f"🔎 <b>Eligible verified fixtures:</b> {total}",
        ""
    ]
    if not preds:
        out += ["<b>NO SAFE PICKS</b>","", "No fixture met the configured safety and data-quality threshold.","", "This is intentional: the bot does not manufacture selections."]
    else:
        for i,p in enumerate(preds,1):
            out += [f"<b>{i}.</b>",prediction_block(p),"────────────",""]
        out += ["<b>SAFE PICKS SUMMARY</b>",""]
        for p in preds:
            f=p.fixture
            out.append(f"{esc(f.home_name)} vs {esc(f.away_name)} | {esc(p.pick)} | {p.confidence:.1f}% | {p.risk}")
        out += ["",f"<b>Selected:</b> {len(preds)}/{maxn}","<b>Important:</b> No football prediction is guaranteed."]
    return "\n".join(out)
