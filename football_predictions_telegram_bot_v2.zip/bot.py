import logging,os
from datetime import date,timedelta
from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application,CommandHandler,ContextTypes
from providers.football_data import FootballDataProvider
from prediction_engine import PredictionEngine
from formatter import report

load_dotenv()
logging.basicConfig(level=logging.INFO,format="%(asctime)s | %(levelname)s | %(message)s")
TOKEN=os.getenv("TELEGRAM_BOT_TOKEN")
DEFAULT_MAX=int(os.getenv("MAX_PICKS_DEFAULT","12"))
MAX_FIX=int(os.getenv("MAX_FIXTURES_TO_ANALYZE","60"))
if not TOKEN: raise RuntimeError("TELEGRAM_BOT_TOKEN is missing")

provider=FootballDataProvider()
engine=PredictionEngine(provider)

async def start(u:Update,c:ContextTypes.DEFAULT_TYPE):
    await u.message.reply_text(
        "⚽ <b>Professional Football Predictions Bot V2</b>\n\n"
        "Exact-date filtering + form model + Poisson markets + safety filtering.\n\n"
        "<b>Commands</b>\n"
        "/today\n/tomorrow\n/predict YYYY-MM-DD [max]\n/help\n\n"
        "No selection is guaranteed.",
        parse_mode=ParseMode.HTML)

async def help_cmd(u,c):
    await u.message.reply_text(
        "<b>Examples</b>\n"
        "<code>/predict 2026-10-05 12</code>\n"
        "<code>/today</code>\n"
        "<code>/tomorrow</code>\n\n"
        "The bot only uses fixtures verified for the requested date.",
        parse_mode=ParseMode.HTML)

def parse(args):
    if not args: raise ValueError()
    d=date.fromisoformat(args[0])
    n=DEFAULT_MAX if len(args)<2 else max(1,min(30,int(args[1])))
    return d,n

async def run(u,day,n):
    m=await u.message.reply_text(f"🔎 Checking verified fixtures for <b>{day.isoformat()}</b>...",parse_mode=ParseMode.HTML)
    try:
        fs=await provider.fixtures_on_date(day)
        fs=[f for f in fs if f.utc_date.date()==day and f.status not in {"POSTPONED","CANCELLED"}]
        fs=fs[:MAX_FIX]
        ps=await engine.analyze_many(fs,n)
        await m.edit_text(report(ps,day,n,len(fs)),parse_mode=ParseMode.HTML,disable_web_page_preview=True)
    except Exception as e:
        logging.exception("prediction run failed")
        await m.edit_text("❌ Reliable fixture/data retrieval failed. No predictions were generated.")

async def predict(u,c):
    try: d,n=parse(c.args)
    except: 
        await u.message.reply_text("Use: /predict YYYY-MM-DD [max]\nExample: /predict 2026-10-05 12")
        return
    await run(u,d,n)

async def today(u,c): await run(u,date.today(),DEFAULT_MAX)
async def tomorrow(u,c): await run(u,date.today()+timedelta(days=1),DEFAULT_MAX)

def main():
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CommandHandler("help",help_cmd))
    app.add_handler(CommandHandler("predict",predict))
    app.add_handler(CommandHandler("today",today))
    app.add_handler(CommandHandler("tomorrow",tomorrow))
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__=="__main__": main()
